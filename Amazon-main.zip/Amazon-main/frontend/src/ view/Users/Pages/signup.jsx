import React from 'react';
import Signup from '../../../Components/Users/Signup/signup';

function signup() {
  return (
      <div>
          <Signup/>
      </div>
  )
}

export default signup;
