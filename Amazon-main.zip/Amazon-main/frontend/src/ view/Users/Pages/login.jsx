import React from 'react';
import Login from '../../../Components/Users/Login/login';

function login() {
  return (
      <div>
          <Login/>
      </div>
  )
}

export default login;
