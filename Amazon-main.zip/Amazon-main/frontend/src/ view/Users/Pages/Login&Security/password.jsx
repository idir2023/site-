import React from 'react'
import Password from '../../../../Components/Users/Profile/password'
import Navbar from '../../../../Components/Users/Navbar/navbar'
import Footer from '../../../../Components/Users/Footer/footer'

function password() {
  return (
    <div>
      <Navbar />
      <Password />
      <Footer />
    </div>
  )
}

export default password