import React from 'react'
import Name from '../../../../Components/Users/Profile/name'
import Navbar from '../../../../Components/Users/Navbar/navbar'
import Footer from '../../../../Components/Users/Footer/footer'

function name() {
  return (
    <div>
      <Navbar />
      <Name />
      <Footer />
    </div>
  )
}

export default name