import React from 'react'
import Email from '../../../../Components/Users/Profile/email'


function name() {
  return (
    <div>

      <Email />

    </div>
  )
}

export default name