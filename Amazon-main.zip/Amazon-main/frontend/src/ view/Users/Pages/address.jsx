import React from 'react';
import Address from '../../../Components/Users/Address/address';
import Navbar from '../../../Components/Users/Navbar/navbar'
import Footer from '../../../Components/Users/Footer/footer'

function address() {
  return (
  <div>
      <Navbar/>
      <Address/>
      <Footer/>
  </div>
  );
}

export default address;
