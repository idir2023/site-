import Departments from '../../../Components/Users/Departments/departments'
import RowPost from '../../../Components/Users/RowPosts/rowPost';




function Home() {


  return (
      <div>
          <Departments/>
          <RowPost/>
      </div>
  )
}

export default Home;